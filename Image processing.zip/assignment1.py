# -*- coding: utf-8 -*-
"""
Created on Mon Feb  1 18:23:35 2021

@author: T530
"""

import matplotlib.pyplot as plt
import cv2
from numpy import asarray
import numpy as np

################# Task-1 #####################################

#gray scale image if value =0
gimg = cv2.imread('capture.jpeg',0)

#plt.imshow(gimg)


#plt.hist(gimg.ravel(),256,[0,256]) 


from PIL import Image, ImageEnhance

#read the image
#im = Image.open('capture.jpeg')
im = Image.open('capture.jpeg').convert('LA')
#image brightness enhancer
enhancer = ImageEnhance.Contrast(im)

factor = 1 #gives original image
im_output1 = enhancer.enhance(factor)
#plt.imshow(im_output1)


im_output1.save('Gray original-image.png')

factor = 0.5 #decrease constrast
im_output2 = enhancer.enhance(factor)
im_output2.save('Gray less-contrast-image.png')
#plt.imshow(im_output2)

factor = 1.5 #increase contrast
im_output3 = enhancer.enhance(factor)
im_output3.save('Gray more-contrast-image.png')
#plt.imshow(im_output3)



################# Task-2 #####################################

#color image if value=1
cimg = cv2.imread('capture.jpeg',1)

#plt.imshow(cimg)

#plt.hist(cimg.ravel(),256,[0,256]) 

im = Image.open('capture.jpeg')

#image brightness enhancer
enhancer = ImageEnhance.Contrast(im)

factor = 1 #gives original image
im_output4 = enhancer.enhance(factor)
#plt.imshow(im_output4)


im_output4.save('color original-image.png')

factor = 0.5 #decrease constrast
im_output5 = enhancer.enhance(factor)
im_output5.save('color less-contrast-image.png')
#plt.imshow(im_output5)

factor = 1.5 #increase contrast
im_output6 = enhancer.enhance(factor)
im_output6.save('color more-contrast-image.png')
#plt.imshow(im_output6)



################# Task-3 #####################################

arrayinput = asarray(gimg)
print(np.shape(arrayinput))

input_data = np.float32(arrayinput) / 255.0
    
# Calculate gradient of Gx and Gy
gx = cv2.Sobel(input_data, cv2.CV_32F, 1, 0, ksize=1)
#plt.imshow(gx)
gy = cv2.Sobel(input_data, cv2.CV_32F, 0, 1, ksize=1)
#plt.imshow(gy) 
gradient_magnitude,angle = cv2.cartToPolar(gx, gy, angleInDegrees=True)


print("----------------Gradient in X direction----------------------")
print(gx)
print("-----------------Gradient in Y direction---------------------")
print(gy )
print("-----------------Magnitude of the image---------------------")
print(gradient_magnitude)
print("------------------Direction of the image--------------------")
print(angle)
print("-----------------Threshold image--------------------")
ret, thresh1 = cv2.threshold(gradient_magnitude, 100, 255, cv2.THRESH_BINARY)
#plt.imshow(thresh1)
print(thresh1)



